Uso: firesim <tamanho-do-problema> <nro. experimentos> <probab. maxima>
Exemplo: firesim 30 5000 101 
